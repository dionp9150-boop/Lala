import '../settings.js';
import pino from 'pino';
import chalk from 'chalk';
import { fileURLToPath } from 'url';
import { Boom } from '@hapi/boom';
import NodeCache from 'node-cache';
import { exec } from 'child_process';
import WAConnection, { useMultiFileAuthState, Browsers, DisconnectReason, makeCacheableSignalKeyStore, fetchLatestWaWebVersion } from 'baileys';

import { GroupParticipantsUpdate, MessagesUpsert, Solving } from './message.js';

global.client = {};

const msgRetryCounterCache = new NodeCache();

async function JadiBot(conn, from, m, store) {
	async function startJadiBot() {
		try {
			const { version } = await fetchLatestWaWebVersion();
			const { state, saveCreds } = await useMultiFileAuthState(`./database/jadibot/${from}`);
			const level = pino({ level: 'silent' })
			
			const getMessage = async (key) => {
				if (store) {
					const msg = await store.loadMessage(key.remoteJid, key.id);
					return msg?.message || ''
				}
				return {
					conversation: 'Halo Saya Adalah Bot'
				}
			}
			
			client[from] = WAConnection({
				version,
				logger: level,
				getMessage,
				syncFullHistory: false,
				maxMsgRetryCount: 15,
				msgRetryCounterCache,
				retryRequestDelayMs: 10,
				defaultQueryTimeoutMs: 0,
				connectTimeoutMs: 60000,
				keepAliveIntervalMs: 30000,
				browser: Browsers.ubuntu('Chrome'),
				generateHighQualityLinkPreview: false,
				transactionOpts: {
					maxCommitRetries: 10,
					delayBetweenTriesMs: 10,
				},
				appStateMacVerification: {
					patch: true,
					snapshot: true,
				},
				auth: {
					creds: state.creds,
					keys: makeCacheableSignalKeyStore(state.keys, level),
				},
			})
			
			await Solving(client[from], store)
			
			client[from].pairingStarted = false;
			
			client[from].ev.on('creds.update', saveCreds)
			
			client[from].ev.on('connection.update', async (update) => {
				const { connection, lastDisconnect, receivedPendingNotifications } = update
				if (connection === 'connecting' && !client[from].authState.creds.registered && !client[from].pairingStarted) {
					setTimeout(async () => {
						if (!client[from]) return;
						client[from].pairingStarted = true;
						exec('rm -rf ./database/jadibot/' + from + '/*');
						let code = await client[from].requestPairingCode(from.replace(/[^0-9]/g, ''));
						if (!client[from]) return;
						m.reply(`Your Pairing Code : ${code?.match(/.{1,4}/g)?.join('-') || code}`);
					}, 3000);
				}
				if (connection === 'close') {
					if (!client[from]) return;
					const reason = new Boom(lastDisconnect?.error)?.output.statusCode
					console.log(reason)
					if ([DisconnectReason.connectionLost, DisconnectReason.connectionClosed, DisconnectReason.restartRequired, DisconnectReason.timedOut, DisconnectReason.badSession, DisconnectReason.connectionReplaced].includes(reason)) {
						JadiBot(conn, from, m, store)
					} else if (reason === DisconnectReason.loggedOut) {
						m.reply('Scan again and Run...');
						StopJadiBot(conn, from, m)
					} else if (reason === DisconnectReason.Multidevicemismatch) {
						m.reply('Scan again...');
						StopJadiBot(conn, from, m)
					} else {
						m.reply('Anda Sudah Tidak Lagi Menjadi Bot!')
					}
				}
				if (connection == 'open') {
					let botNumber = await client[from].decodeJid(client[from].user.id);
					if (db.set[botNumber] && !db.set[botNumber]?.join) {
						db.set[botNumber].original = false
						if (my.ch.length > 0 && my.ch.includes('@newsletter')) {
							if (my.ch) await client[from].newsletterMsg(my.ch, { type: 'follow' }).catch(e => {})
							db.set[botNumber].join = true
						}
					}
				}
				if (receivedPendingNotifications == 'true') {
					client[from].ev.flush()
				}
			});
			
			client[from].ev.on('call', async (call) => {
				let botNumber = await client[from].decodeJid(client[from].user.id);
				if (db.set[botNumber].anticall) {
					for (let id of call) {
						if (id.status === 'offer') {
							let msg = await client[from].sendMessage(id.from, { text: `Saat Ini, Kami Tidak Dapat Menerima Panggilan ${id.isVideo ? 'Video' : 'Suara'}.\nJika @${id.from.split('@')[0]} Memerlukan Bantuan, Silakan Hubungi Owner :)`, mentions: [id.from]});
							await client[from].sendContact(id.from, global.owner, msg);
							await client[from].rejectCall(id.id, id.from)
						}
					}
				}
			});
			
			client[from].ev.on('groups.update', (update) => {
				for (let n of update) {
					if (store.groupMetadata[n.id]) {
						Object.assign(store.groupMetadata[n.id], n);
					} else store.groupMetadata[n.id] = n;
				}
			});
			
			client[from].ev.on('group-participants.update', async (update) => {
				await GroupParticipantsUpdate(client[from], update, store);
			});
			
			client[from].ev.on('messages.upsert', async (message) => {
				await MessagesUpsert(client[from], message, store);
			});
		
			return client[from]
		} catch (e) {
			console.log(chalk.redBright(`[ERROR] ${e}`))
		}
	}
	return startJadiBot()
}

async function StopJadiBot(conn, from, m) {
	if (!Object.keys(client).includes(from)) {
		return conn.sendMessage(m.chat, { text: 'Anda Tidak Sedang jadibot!' }, { quoted: m })
	}
	try {
		client[from].ev.removeAllListeners()
		if (client[from].ws) client[from].ws.close()
		client[from].end('Stop')
	} catch (e) {
		console.log(chalk.redBright(`[ERROR] ${e}`))
	}
	delete client[from]
	exec(`rm -rf ./database/jadibot/${from}`)
	return m.reply('Sukses Keluar Dari Sessi Jadi bot')
}

async function ListJadiBot(conn, m) {
	let teks = 'List Jadi Bot :\n\n'
	for (let jadibot of Object.values(client)) {
		teks += (jadibot.user?.id ? `- @${conn.decodeJid(jadibot.user.id).split('@')[0]}\n` : '')
	}
	return m.reply(teks)
}

export { JadiBot, StopJadiBot, ListJadiBot };